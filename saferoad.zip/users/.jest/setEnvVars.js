require("dotenv").config(".env");
